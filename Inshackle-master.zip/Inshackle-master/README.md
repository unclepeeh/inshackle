# Inshackle v1.0
# Instagram bot,auto follower
## Recoded: github.com/Dark-Devill/inshackle
### Don't copy this code without give me the credits, nerd! Please read the License 
### thanks to linuxchoice
Instagram hacks: Track unfollowers, Increase your followers, Download Stories, etc

### Features:
#### Unfollow Tracker
#### Increase Followers
#### Download: Stories, Saved Content, Following/followers list, Profile Info
#### Unfollow all your following

![ins](https://user-images.githubusercontent.com/56509491/66778205-b18ad580-eee8-11e9-8904-2c536b1a365d.JPG)

### Usage:
```
git clone https://github.com/cyberkallan/inshackle-bot
cd inshackle-bot
bash inshackle.sh
```
